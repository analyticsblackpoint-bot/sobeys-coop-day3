# Day 4 · student pack

Build an AI assistant, test it, pitch it. Friday, November 6, 2026.

| File | Use it when |
|---|---|
| `Prompt Lab.html` | Before the build: double-click it (works offline) or use the link on the board. Type a prompt for your hat, score it, fix it, keep your best one (8+). |
| `Day 4 Brief and Rubric.pdf` | The one-page task sheet and the rubric (24 points). Read first. |
| `Day 4 Build Workbook.pdf` (and `.docx`) | The seven steps, the assistant card, the fact sheet, the red-team log, the pitch outline, the submit checklist. |
| `skills\cards\` | Five one-page cards. Copy from `BEGIN` to `END` into any free chatbot, fill in the blanks, send once: Fact Finder → System Prompt Writer → Bot Builder → Red-Team Tester → Pitch Coach. |
| `skills\<name>\SKILL.md` | The full skill: the same box, plus the Snack Bar example filled in, fix-it prompts, and why each rule exists. |
| `Snack Bar Assistant.html` | The finished example (the answer key). Double-click to open; works offline. Prices and stock are practice numbers. |
| `Day 4 Slides (students, no notes).pptx` / `.pdf` | The slides from class. |

The rules, all day: no real people in anything you generate · nothing explicit · no names, emails or phone numbers in a prompt, a file or a bot · facts with links only · the bot never invents.

Submit by 12:18: email your `.html` + a photo of your assistant card (with initials) + your red-team log to the address on the board. Subject line: your team name.
